Running the make_file as is using ./make_file opens the server on port 1500

to run the client just run ./project1Client [IP] [PORT]

I HAVE USED CODE FROM THE D&H SAMPLE CODE ONLINE AS WELL AS I HAVE REFERENCED
STACKOVERFLOW AT: http://stackoverflow.com/questions/15708793/c-convert-an-uppercase-letter-to-lowercase 

The length of the file I obtained was 501610 bytes, the result of the shasum program on this file is 94b51dc74056d45916bc87b8707e88a50be86fa5

when running project1Server on port 5, the binding fails and a Permission denied error is issued

iv. Is there any humanly-discernable difference between the time taken for the byteAtATimeCmd and the kByteAtATimeCmd commands in the test run? 
Do you think there is an actual difference? What might we do to observe the difference? 

No there is no humanly discernable difference between the times taken.
I think there is a difference in time because there is a huge difference in the amount
of data sent and it would seem almost unrealistic to say that this would not affect
the time taken. Perhaps a time could be recorded at which the data is sent and a time
could be recorded when it is received to see the difference.

v. How many hours did you spend on this project? If two people worked together report the number of hours worked separately for each person.

Honestly, way too many, I lost track, definitely > 20. I was completely lost but I like to think
that I'm good enough at programming that I don't need help. I will definitely start
the next assignment earlier and ask for help ahead of time.